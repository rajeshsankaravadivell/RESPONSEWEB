package com.example.outlook

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
